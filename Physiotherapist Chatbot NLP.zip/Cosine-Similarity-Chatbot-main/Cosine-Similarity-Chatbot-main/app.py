from flask import Flask, render_template, request, jsonify
from chat import chatbot

app = Flask(__name__)

@app.route("/")
def home():
    return render_template('chat.html')  # Ensure you have a 'chat.html' file in your templates directory

@app.route("/ask", methods=['POST'])
def ask():
    message = str(request.form['messageText'])
    bot_response = chatbot(message)  # Get the chatbot's response
    return jsonify({'status': 'OK', 'answer': bot_response})

if __name__ == "__main__":
    app.run(debug=True)  # Add debug=True for easier development and debugging
