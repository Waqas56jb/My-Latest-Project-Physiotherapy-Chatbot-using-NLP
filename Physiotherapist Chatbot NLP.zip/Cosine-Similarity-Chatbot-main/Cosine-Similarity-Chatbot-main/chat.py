from db_call import QASystem

def chatbot(input_text):
    qa = QASystem('test.csv')  # Replace 'test.csv' with the path to your actual CSV file
    try:
        qa_response = qa.get_response(input_text)
    except Exception as e:
        print(f"Error: {e}")  # Log the error for debugging
        qa_response = "I can't answer this question."

    return qa_response
